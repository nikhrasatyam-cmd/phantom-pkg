# phantom-pkg

Validate LLM-recommended npm packages before you install them.

## The Problem

LLMs hallucinate npm package names. Sonatype's 2026 research found that 28% of
LLM-assisted dependency recommendations reference non-existent or incorrect packages.
Real packages can also be **typosquats** — malicious clones of popular packages
registered under subtly misspelled names.

`phantom-pkg` catches both problems *before* `npm install` runs.

## Installation

```bash
npm install -g phantom-pkg
```

## Usage

### Check packages directly

```bash
phantom-pkg check lodash axios reactt
```

### Read from stdin

```bash
echo "lodash\naxios\nlodahs" | phantom-pkg check --stdin

# Or pipe from another command
cat packages.txt | phantom-pkg check --stdin

# From package.json dependencies
cat package.json | jq -r '.dependencies | keys[]' | phantom-pkg check --stdin
```

### Read from a file

```bash
# Automatically parses dependencies, devDependencies, peerDependencies
phantom-pkg check --file package.json

# One package name per line
phantom-pkg check --file packages.txt
```

## CLI Options

| Flag                    | Short | Description                                    | Default  |
|-------------------------|-------|------------------------------------------------|----------|
| `--format <type>`       | `-f`  | Output format: `table`, `json`, `minimal`      | `table`  |
| `--timeout <ms>`        | `-t`  | Registry request timeout in ms                 | `5000`   |
| `--fail-on-suspicious`  |       | Exit code 1 if any suspicious packages found   | off      |
| `--verbose`             | `-v`  | Show all packages in minimal format            | off      |
| `--stdin`               |       | Read package names from stdin                  | off      |
| `--file <path>`         |       | Read from a `.txt` file or `package.json`      | —        |

## Output Formats

### Table (default)

```
Package Name              Status           Downloads/wk   Age    Note
──────────────────────────────────────────────────────────────────────────────
lodash                    ✓ exists         50.0M          11yr
reactt                    ✗ NOT FOUND      -              -
lo-dash                   ✗ TYPOSQUAT      1K             1mo    Possible typosquat of "lodash"
weird-pkg                 ⚠ suspicious     45             2d     low downloads for a new package
──────────────────────────────────────────────────────────────────────────────

Checked 4 packages: 1 safe, 1 suspicious, 1 not found, 1 typosquat
```

### JSON

```bash
phantom-pkg check lodash reactt --format json
```

```json
{
  "total": 2,
  "safe": 1,
  "suspicious": 0,
  "notFound": 1,
  "typosquats": 0,
  "errors": 0,
  "results": [
    {
      "name": "lodash",
      "status": "exists",
      "signals": { "weeklyDownloads": 50234567, "publishedDaysAgo": 4015, ... },
      "typosquatOf": null,
      "message": "Package \"lodash\" exists and appears legitimate",
      "registryUrl": "https://www.npmjs.com/package/lodash"
    },
    {
      "name": "reactt",
      "status": "not-found",
      ...
    }
  ]
}
```

### Minimal

```bash
phantom-pkg check lodash reactt lo-dash --format minimal
```

```
not-found    reactt
typosquat    lo-dash
```

Only shows problematic packages by default. Use `--verbose` to show all packages.

```bash
phantom-pkg check lodash reactt --format minimal --verbose
```

```
exists       lodash
not-found    reactt
```

## Programmatic API

```typescript
import { checkPackage, checkPackages, formatReport } from 'phantom-pkg'

// Check a single package
const result = await checkPackage('lodash', { timeout: 5000 })
console.log(result.status)      // 'exists'
console.log(result.signals)     // { weeklyDownloads: 50234567, ... }
console.log(result.typosquatOf) // null

// Check multiple packages at once
const summary = await checkPackages(['lodash', 'reactt', 'lo-dash'], {
  timeout: 5000,
  failOnSuspicious: false,
})
console.log(`${summary.notFound} package(s) not found`)
console.log(`${summary.typosquats} possible typosquat(s)`)

// Format results for display
const report = formatReport(summary, { format: 'table' })
process.stdout.write(report + '\n')
```

### Types

```typescript
type PackageStatus = 'exists' | 'not-found' | 'suspicious' | 'typosquat' | 'error'

interface CheckResult {
  name: string
  status: PackageStatus
  signals: PackageSignals | null
  typosquatOf: string | null
  message: string
  registryUrl: string
}

interface PackageSignals {
  weeklyDownloads: number | null
  publishedDaysAgo: number | null
  hasReadme: boolean
  hasRepository: boolean
  maintainerCount: number | null
  versionCount: number | null
  isDeprecated: boolean
}
```

## How Signals Work

A package is flagged as **suspicious** if *any* of the following are true:

| Signal | Threshold |
|--------|-----------|
| Low downloads + new | < 100 weekly downloads AND published < 30 days ago |
| No maintainers | Zero or unknown maintainer count |
| No metadata | Neither a README nor a repository link |
| Deprecated | Package is marked deprecated on the registry |
| Unavailable count | Weekly download count could not be fetched |

## How Typosquat Detection Works

`phantom-pkg` maintains a list of the 50 most popular npm packages and compares
incoming names against it using four techniques:

1. **Edit distance** — names within 2 character edits are flagged (`lodahs` → `lodash`)
2. **Separator swaps** — hyphens and underscores are interchangeable (`lo_dash` → `lodash`)
3. **Missing or extra hyphens** — `reactdom` is compared against `react-dom`
4. **`js` suffix confusion** — `momentjs` and `moment-js` are compared against `moment`

Exact matches are never flagged — `lodash` is not a typosquat of `lodash`.

## Exit Codes

| Code | Meaning |
|------|---------|
| `0`  | All packages are safe (`exists`) |
| `1`  | One or more packages are `not-found` or `typosquat`; also `suspicious` with `--fail-on-suspicious` |
| `2`  | Fatal error — registry unreachable, file not found, invalid input |

## CI Integration

```yaml
# .github/workflows/dependency-check.yml
- name: Validate dependencies
  run: phantom-pkg check --file package.json --fail-on-suspicious
```

## Contributing

Contributions are welcome! Please open an issue or pull request on GitHub.

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes and add tests
4. Run `npm test` to ensure all tests pass
5. Run `npm run typecheck` to confirm zero TypeScript errors
6. Submit a pull request

## License

MIT
